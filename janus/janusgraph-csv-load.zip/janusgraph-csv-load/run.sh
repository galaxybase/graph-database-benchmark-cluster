#!/bin/bash
whetherSplitFile=$1
dataPath=$2
vertexFile=$3
edgeFile=$4
propertyFile=$5
workSpace=$(pwd)
cd $workSpace
edgeFiles=$edgeFile",1~1"
if [ $whetherSplitFile == "true" ]; then
  bash FileSplitor.sh $dataPath edge.csv 20
  edgeFiles=$edgeFile",1~20"
fi
echo "start load"
bash JanusLoader.sh $dataPath $vertexFile $edgeFiles $propertyFile
