package com.cl.janus;

import org.janusgraph.core.JanusGraph;
import org.janusgraph.core.JanusGraphFactory;
import org.janusgraph.core.JanusGraphTransaction;
import org.janusgraph.core.JanusGraphVertex;
import org.janusgraph.core.PropertyKey;
import org.janusgraph.graphdb.database.management.ManagementSystem;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class VertexLoader {

    private static int commitBatch = 4000;

    private static Map<String, Long> vertexes = new ConcurrentHashMap<>();

    private static List<String> fileBuffer = new ArrayList<>(50000000);

    private static final int THREAD_NUM = 12;

    private static ExecutorService pool = Executors.newFixedThreadPool(THREAD_NUM, new MyThreadFactory());


    public static void main(String[] args) throws FileNotFoundException {

        String properties = args[0];
        String vertexFile = args[1];
        if (vertexFile == null) {
            vertexFile = "vertex.csv";
        }

        JanusGraph JanusG = JanusGraphFactory.open(properties);

        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(vertexFile)));
        readFile2Buffer(fileBuffer, reader);

//        创建图结构
        ManagementSystem mgmt = (ManagementSystem) JanusG.openManagement();
        mgmt.makeEdgeLabel("MyEdge").make();
        mgmt.makeVertexLabel("MyNode").make();
        PropertyKey id_key = mgmt.makePropertyKey("id").dataType(String.class).make();
        mgmt.buildIndex("byId", JanusGraphVertex.class).addKey(id_key).unique().buildCompositeIndex();
        mgmt.commit();

        long startTime=System.nanoTime();
        addVertex(JanusG,commitBatch);

        pool.shutdown();
        try {
            pool.awaitTermination(1440, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long endTime=System.nanoTime(); //获取结束时间

        System.out.println("程序运行时间： "+((endTime-startTime) / 1000 / 1000 / 1000.0)+"s");
        try {
            FileWriter writer = new FileWriter("hashMap", true);
            System.out.println(vertexes.size());
            Iterator<String> keySet = vertexes.keySet().iterator();
            while (keySet.hasNext()) {
                String next = keySet.next();
                writer.write(next + "," + vertexes.get(next) + "\n");
            }
            writer.close();
//            点导入耗时信息输出
            writer = new FileWriter("vertexLoad", true);
            writer.write("Vertex Load,Program run time: "+((endTime-startTime) / 1000 / 1000 / 1000.0)+"s");
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JanusG.close();
    }

    public static void batchCommit(JanusGraph JanusG, final List<String> vids) {
        pool.submit(() -> {
            JanusGraphTransaction tx = JanusG.newTransaction();
            for (String vid : vids) {
                long id = Long.parseLong(vid);
                JanusGraphVertex srcVertex = tx.addVertex("MyNode");
                srcVertex.property("id", id);
                vertexes.put(vid, (Long) srcVertex.id());
            }
            tx.commit();
        });
    }


    /**
     * 添加点
     * @param JanusG
     * @param commitBatch
     */
    public static void addVertex(JanusGraph JanusG, int commitBatch) {
        List<String> vids = new ArrayList<>(commitBatch + 1);
        for (String vid : fileBuffer) {
            vids.add(vid);
            if (vids.size() == commitBatch) {
                List<String> cVids = vids;
                vids = new ArrayList<>(commitBatch + 1);
                batchCommit(JanusG, cVids);
            }
        }
        batchCommit(JanusG, vids);
    }

    /** this function read file from disk to memory
     * @para reader buffering characters
     */
    private static void readFile2Buffer(List<String> fileList, BufferedReader reader) {
        try {
            String line;
            while((line = reader.readLine()) != null) {
                fileList.add(line);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    /** this class define name for threads
     */
    public static class MyThreadFactory implements ThreadFactory {
        private int counter = 0;
        public Thread newThread(Runnable r) {
            return new Thread(r, "" + counter++);
        }
    }

}
