package com.cl.janus;

import org.janusgraph.core.JanusGraph;
import org.janusgraph.core.JanusGraphEdge;
import org.janusgraph.core.JanusGraphFactory;
import org.janusgraph.core.JanusGraphTransaction;
import org.janusgraph.core.JanusGraphVertex;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class EdgeLoader {

    private static int commitBatch = 4000;

    private static Map<String, Long> vertexes = new HashMap<>();

    private static List<String> fileBufferEdge = new ArrayList<>(80000000);

    private static final int THREAD_NUM = 12;

    private static CountDownLatch latch = new CountDownLatch(THREAD_NUM);
    private static ExecutorService pool = Executors.newFixedThreadPool(THREAD_NUM, new MyThreadFactory());


    public static void main(String[] args) throws FileNotFoundException {

        String properties = args[0];
        String edgeFile = args[1];
        if (edgeFile == null) {
            edgeFile = "edge.csv";
        }

        JanusGraph JanusG = JanusGraphFactory.open(properties);

        BufferedReader vreader = new BufferedReader(new InputStreamReader(new FileInputStream("hashMap")));
        readFile2Map(vreader);

        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(edgeFile)));
        readFile2Buffer(fileBufferEdge, reader);

        long startTime=System.nanoTime();

        addEdges(JanusG,commitBatch);
        pool.shutdown();
        try {
            pool.awaitTermination(1440, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        JanusG.close();

        long endTime=System.nanoTime(); //获取结束时间

        System.out.println("程序运行时间： "+((endTime-startTime) / 1000 / 1000 / 1000.0)+"s");
        try {
            FileWriter writer = new FileWriter("edgeLoad", true);
            writer.write("Edge Load,Program run time: "+((endTime-startTime) / 1000 / 1000 / 1000.0)+"s\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void batchCommitEdge(JanusGraph JanusG, final List<String> vids) {
        pool.submit(() -> {
            JanusGraphTransaction tx = JanusG.newTransaction();
            for (String vid : vids) {
                String[] parts = vid.split(",");
                Long src = vertexes.get(parts[0]);
                Long tgt = vertexes.get(parts[1]);
                JanusGraphVertex srcVertex = tx.getVertex(src);
                JanusGraphVertex dstVertex = tx.getVertex(tgt);
                JanusGraphEdge edge = srcVertex.addEdge("MyEdge", dstVertex);
            }
            tx.commit();
        });
    }

    public static void addEdges(JanusGraph JanusG, int commitBatch) {
        List<String> vids = new ArrayList<>(commitBatch + 1);
        for (String vid : fileBufferEdge) {
            vids.add(vid);
            if (vids.size() == commitBatch) {
                List<String> cVids = vids;
                vids = new ArrayList<>(commitBatch + 1);
                batchCommitEdge(JanusG, cVids);
            }
        }
        batchCommitEdge(JanusG, vids);
    }

    /** this function read file from disk to memory
     * @para reader buffering characters
     */
    private static void readFile2Buffer(List<String> fileList, BufferedReader reader) {
        try {
            String line;
            while((line = reader.readLine()) != null) {
                fileList.add(line);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private static void readFile2Map(BufferedReader reader) {
        try {
            String line;
            while((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String out = parts[0];
                Long in = Long.parseLong(parts[1]);
                vertexes.put(out, in);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    /** this class define name for threads
     */
    public static class MyThreadFactory implements ThreadFactory {
        private int counter = 0;
        public Thread newThread(Runnable r) {
            return new Thread(r, "" + counter++);
        }
    }

}
