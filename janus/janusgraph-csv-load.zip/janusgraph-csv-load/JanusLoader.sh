#!/bin/bash
dataPath=$1
vertexFile=$2
edgeFiles=$3
propertyFile=$4
workPath=$(pwd)
cd $workPath
mvn install
mvn exec:java -Dexec.mainClass="com.cl.janus.VertexLoader" -Dexec.args="$propertyFile $dataPath/$vertexFile"
echo "vertex load done!"
edgeFileName=$(echo $edgeFiles | awk -F '[,.]' '{print $1}')
edgeStart=$(echo $edgeFiles | awk -F '[,~]' '{print $2}')
edgeEnd=$(echo $edgeFiles | awk -F '[,~]' '{print $3}')
echo "start load edge"
printf "loading...[0/$edgeEnd]"
for i in $(seq $edgeStart $edgeEnd); do
  file=$edgeFileName$i".csv"
  mvn exec:java -Dexec.mainClass="com.cl.janus.EdgeLoader" -Dexec.args="$propertyFile $dataPath/$file"
  printf "\rloading...[$i/$edgeEnd]"
done
