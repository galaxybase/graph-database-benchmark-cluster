#!/bin/bash
dataPath=$1
fileName=$2
part=$3
workSpace=$(pwd)
cd $workSpace
line=$(cat $dataPath/$fileName | wc -l)
split=$(($line / $part))
cat $dataPath/$fileName | awk -F '[\t]' '{print $1","$2}' >temp.csv
fileName="temp.csv"
printf "[0/$part]"
for i in $(seq 1 $(($part - 1))); do
  newFileName="edge$i.csv"
  start=$((($i - 1) * $split + 1))
  cat $dataPath/$fileName | tail -n +$start | head -n $split >$newFileName
  printf "\r[$i/$part]"
done
newFileName="edge$part.csv"
start=$((($part - 1) * $split + 1))
cat $dataPath/$fileName | tail -n +$start >$newFileName
printf "All file splited!\n"
rm -r temp.csv
