# Janusgraph数据导入文档

## 1. 获取导入脚本

``git pull janusgrpah-csv-load``

## 2. 执行导入脚本

``bash run.sh false /datapath vertex.csv edge.csv janusgraph-g500d.properties``

导入配置参数如下：

| 参数名称         | 内容                                                         |
| ---------------- | ------------------------------------------------------------ |
| whetherSplitFile | 选填`true`或者`false`，是否需要切分csv文件。twitter-2010的边文件行数较多需要进行切分，默认切分为20份 |
| dataPath         | 存放csv文件的文件夹路径                                      |
| vertexFile       | 点csv文件的名称                                              |
| edgeFile         | 边csv文件的名称                                              |
| propertyFile     | janusgraph-cassandra导入配置文件(项目根目录提供`janusgraph-cassandra.properties`)的名称，需要修改`storage.hostname`为集群ip地址集，`index.search.hostname`为elasticsearch的ip地址，`storage.cql.keyspace`为图名称 |
